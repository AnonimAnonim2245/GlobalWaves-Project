package types;

import database.Database;

import java.util.List;
import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

/**
 * In the host function, there are the announcements and podcasts
 * classes related the host
 */
@Getter
public class Host {
    @Setter
    private String pageStatus = "HOME";
    @Setter
    private List<Announcement> announcements = new ArrayList<>();
    @Setter
    private List<Podcast> podcasts = new ArrayList<>();
    private String username;
    private final Database userDatabase;

    public Host() {
        this.userDatabase = new Database();
    }

    public Host(final String username) {
        this.username = username;
        this.userDatabase = new Database();
    }

    /**
     * removes all podcasts
     */
    public void removeAllPodcasts() {
        for (Podcast podcast : podcasts) {
            Library.getDatabase().getPodcasts().removeIf(podcast2 -> podcast2.getName().
                    equals(podcast.getName()));
        }
        podcasts.clear();
    }

    /**
     * add a certain podcast
     * @param podcast2 the podcast with its episodes
     */
    public void addPodcast(final Podcast podcast2) {
        podcasts.add(podcast2);
    }

    /**
     * checks if the announcement exists
     * @param name the name of the
     *             supposed announcement
     * @return true or false
     */
    public boolean checkIfAnnouncementExists(final String name) {
        for (Announcement announcement : announcements) {
            if (announcement.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

}
