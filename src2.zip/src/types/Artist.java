package types;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import database.Database;
import json.JsonConvertToCategories;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * Artist class
 * with username, events, merch
 * and the methods to add and remove events
 * and merch
 * and to check if the name of the event exists
 * and to check if the name of the merch exists
 * and to add albums
 * and to sum the likes of the songs of an artist
 */
@Getter
public class Artist {
    @Setter
    private String pageStatus = "HOME";
    private String username;
    private ArrayList<Event> events = new ArrayList<>();
    private ArrayList<Merch> merchList = new ArrayList<>();
    private final Database userDatabase;
    private ArrayList<Album> albums = new ArrayList<>();

    public Artist() {
        this.userDatabase = new Database();
    }

    /**
     * check if the name of the event
     * exists
     * @param name the name of the
     *             supposed event
     * @return true or false
     */
    public boolean checkIfEventExists(final String name) {
        for (Event event : events) {
            if (event.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    /**
     * check if the name of the merch exists
     * already
     * @param name the name of the supposed
     *             merch
     * @return true or false
     */
    public boolean checkIfMerchExists(final String name) {
        for (Merch merch : merchList) {
            if (merch.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    public Artist(final String username) {
        this.username = username;
        this.userDatabase = new Database();
    }

    /**
     * add album to the list
     * @param album the name of the album
     */
    public void addAlbum(final Album album) {

        albums.add(album);
    }

    /**
     * the sum of the likes of the songs of an artist
     * by considering all the albums
     * @return that sum
     */
    public Integer sumofLikeAlbumsUsers() {
        Integer sum = 0;
        for (Album album : this.getAlbums()) {
            sum += album.sumofLikesongAlbums();
        }
        return sum;
    }

    /**
     * returns the top5 artists by number of likes by alum
     * @return the json node
     */
    public JsonNode top5Artist() {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode jsonObject = new ObjectMapper().createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        User user = Library.getDatabase().getUserInstance(jsonElement.getUsername());
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        ArrayNode outputs = objectMapper.createArrayNode();
        List<String> top5Artist = user.getUserDatabase().getTop5Artists();
        for (String top5 : top5Artist) {
            outputs.add(top5);
        }
        jsonObject.set("result", outputs);

        return jsonObject;

    }

}
