package types;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Setter;
import json.JsonConvertToCategories;
import lombok.Getter;

import java.util.*;

/**
 * Library is our mother class on which we have all the operations that
 * we access in common
 * for all users, that's also why we take input for songs, podcasts,
 * playlists(PlaylistList)
 * that's why we take the json values. Here we also convert users to
 * hasmap to make it easier
 * this only once in our function
 * of the user's name (we make a singleton per user).
 * We have a final function that converts input from the test into classes to use
 * to filter information and for
 * to process the data.
 * We have the instance function, in which we make a lazy instance of
 * the singleton so that we can
 * take the data only once, we do with singleton
 * so that we can access the information previously added by me.
 * We have the addPlaylistList function in which we add playlists,
 * and removeAllPlaylists in
 * which we delete respectively
 * I have a function that searches for the song by name, this somehow makes
 * it easier when we need it
 * enter the name
 * songs , and we want to modify or read information
 * Search Song by name returns the name of the song index, which we use
 * to process the information in it.
 * GetUserInstance checks if we did the instantiation once again, and not again
 * makes and returns the usermap
 * which represents the hashmap of our user. And if he checks that he was not notified
 * and does not contain it, we make one.
 * we implemented for stage 2 also for artists, hosts, which are the same as users
 * a hashmap, which verifies if the certain name was
 * instantiated oncewe implemented design pattern flyweight,
 * and we also implemented functions of
 * checking if the artist, the host, the user exists, and functions to
 * delete them all
 */
public final class Library {
    @Getter
    private JsonConvertToCategories json = new JsonConvertToCategories();
    private Map<String, User> userMap = new HashMap<>();

    private Map<String, Artist> artistMap = new HashMap<>();
    private Map<String, Host> hostMap = new HashMap<>();
    @Getter
    private final List<JsonConvertToCategories> jsonList = new ArrayList<>();
    @Getter
    private ArrayList<Song> songs;
    @Getter
    private List<Playlist> playlistList = new ArrayList<>();
    @Getter
    private List<String> accesedUsers = new ArrayList<>();
    @Getter
    private List<Album> albums = new ArrayList<>();
    @Getter
    private ArrayList<Podcast> podcasts;
    @Getter
    @Setter
    private String hostElement = "";
    @Getter
    @Setter
    private String artistElement = "";

    @Getter
    @Setter
    private Boolean barrier = false;
    @Getter
    @Setter
    private String pageStatus = "HOME";

    @Getter
    private ArrayList<User> users;
    @Getter
    private ArrayList<Host> hosts = new ArrayList<>();
    @Getter
    private ArrayList<Artist> artists = new ArrayList<>();


    private static Library instance = null;
    private static int count;

    /**
     * add an album
     * @param album the album
     */
    public void addAlbum(final Album album) {
        albums.add(album);
    }

    /**
     * add a user
     * @param user the user
     */
    public void addUser(final User user) {
        Library.getDatabase().getUsers().add(user);
    }

    /**
     * add a host
     * @param host
     */
    public void addHost(final Host host) {
        hosts.add(host);
    }

    /**
     * add an artist
     * @param artist
     */
    public void addArtist(final Artist artist) {
        artists.add(artist);
    }


    /**
     * singleton process for getDatabase()
     *
     * @return instance
     * implements lazy singleton design pattern
     */
    public static Library getDatabase() {
        if (instance == null) {
            instance = new Library();
        }
        count++;
        return instance;

    }

    /**
     * add a podcast
     * @param podcast the current podcast
     */
    public void addPodcast(final Podcast podcast) {
        podcasts.add(podcast);
    }

    /**
     * removes an element from a playlist
     */
    public void addSongs(final ArrayList<Song> songsCopy) {
        this.songs.addAll(songsCopy);
    }

    /**
     * removes all the playlists
     */
    public void removeAllPlaylists() {
        this.playlistList.removeAll(this.getPlaylistList());
    }

    /**
     * set the json
     */
    public void setJson(final JsonConvertToCategories json) {
        this.json = json;
    }


    /**
     * check if artist was instantiated
     * @param username username artist
     * @return true or false
     */
    public boolean checkifArtistInstance(final String username) {
        return (artistMap.containsKey(username));

    }
    /**
     * check if user was instantiated
     * @param username username normal user
     * @return true or false
     */

    public boolean checkifUserInstance(final String username) {
        return (userMap.containsKey(username));

    }

    /**
     * added artist instance which verifies the key only once
     * @param username username
     * @return the hashmap with username
     * implements the flyweight design pattern
     */
    public Artist getArtistInstance(final String username) {
        if (!artistMap.containsKey(username)) {
            artistMap.put(username, new Artist(username));
        }
        return artistMap.get(username);
    }
    /**
     * added host instance which verifies the key only once
     * @param username username
     * @return the hashmap with username
     * implements the flyweight design pattern
     */
    public Host getHostInstance(final String username) {
        if (!hostMap.containsKey(username)) {
            hostMap.put(username, new Host(username));
        }
        return hostMap.get(username);
    }

    /**
     * checks if the user is valid
     * @param username the username
     * @return true or false
     */
    public boolean checkIfNormalUserValid(final String username) {
        for (User user : users) {
            if (user.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }
    /**
     * removes all the playlists
     */

    public void removeAllArtists() {
        this.artists.clear();
    }

    /**
     * removes all the albums
     */
    public void removeAllAlbums() {
        this.albums.clear();
    }
    /**
     * removes all the hosts and all their announcements
        */
    public void removeAllHosts() {
        for (Host host : hosts) {
            host.getAnnouncements().clear();

        }
        Library.getDatabase().getHosts().clear();
    }

    /**
     * checks if the artist is valid and
     * is on the artists list
     * @param username the current artist
     * @return
     */
    public boolean checkIfArtistValid(final String username) {
        for (Artist artist : artists) {
            if (artist.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }

    /**
     * return a certain artist by name
     * @param username the name to be searched
     *                 in the artist list
     * @return artist class or null,
     * if wasn't found
     */
    public Artist returnArtist(final String username) {
        for (Artist artist : artists) {
            if (artist.getUsername().equals(username)) {
                return artist;
            }
        }
        return null;
    }

    /**
     * checks if the album exists
     * @param name the name of the album
     *             we check if it exists
     * @return true or false
     */
    public boolean checkIfAlbumExists(final String name) {

        for (Artist artist : Library.getDatabase().getArtists()) {
            for (Album album : Library.getDatabase().
                    getArtistInstance(artist.getUsername()).getAlbums()) {
                if (album.getName().equals(name)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * checks if the album of a certain artist exists
     * @param name the name of the album
     * @param user  the name of the artist
     * @return true or false
     */
    public boolean checkIfAlbumUserExists(final String name,
                                          final String user) {

        for (Artist artist : Library.getDatabase().getArtists()) {
            if (artist.getUsername().equals(user)) {
                for (Album album : Library.getDatabase().
                        getArtistInstance(artist.getUsername()).getAlbums()) {
                    if (album.getName().equals(name)) {
                        return true;
                    }
                }
            }

        }

        return false;
    }

    /**
     * checks if the podcast exists
     * @param name the name of podcast
     *             we search
     * @return true or false
     */
    public boolean checkIfPodcastExists(final String name) {

        for (Podcast podcast : Library.getDatabase().getPodcasts()) {
            if (podcast.getName().equals(name)) {
                return true;
            }
        }

        return false;
    }

    /**
     * checks if the host exists or valid
     * @param username the name of our
     *                 supposed host
     * @return true or false
     */
    public boolean checkIfHostValid(final String username) {
        for (Host host : hosts) {
            if (host.getUsername().equals(username)) {
                return true;
            }
        }
        return false;
    }



    /**
     * converts Lists to Map with a string paramet
     */
    public void convertListToMap() {
        Map<String, User> stringUserHashMap = new HashMap<>();
        for (User user : users) {
            stringUserHashMap.put(user.getUsername(), user);
        }
        this.userMap = stringUserHashMap;
    }

    /**
     * adds playlist
     */
    public void addPlaylistList(final Playlist playlistList2) {
        if (this.playlistList.isEmpty()) {
            List<Playlist> list = new ArrayList<>();
            list.add(playlistList2);
            this.playlistList = list;
            return;
        }

        this.playlistList.add(playlistList2);
    }

    /**
     * added jsonlist
     */
    public void addJsonList(final List<JsonConvertToCategories> jsonList2) {
        if (this.jsonList.equals(jsonList2)) {
            return;
        }
        this.jsonList.removeAll(this.getJsonList());
        this.jsonList.addAll(jsonList2);

    }

    /**
     * added user instance which verifies the key only once
     *
     * @param username username
     * @return the hashmap with username
     * implements the flyweight design pattern
     */

    public User getUserInstance(final String username) {
        if (!userMap.containsKey(username)) {
            userMap.put(username, new User(username));
        }
        return userMap.get(username);
    }


    /**
     * gets podcast by name
     *
     * @param name name of the podcast
     * @return podcast with that name
     */
    public static Podcast podcastByName(final String name) {
        List<Podcast> podcasts = Library.getDatabase().getPodcasts();
        for (Podcast podcast : podcasts) {
            if (podcast.getName().startsWith(name)) {
                return podcast;
            }
        }
        return null;
    }

    /**
     * searches for an album by its name
     * @param name
     * @return
     */
    public static Album searchAlbumByName(final String name) {
        int i = 0;
        for (Album album : Library.getDatabase().getAlbums()) {
            if (album.getName().equals(name)) {
                return album;
            }
            i++;
        }
        return null;
    }

    /**
     * deteletes all the traces of a certain user
     * such as songs, preffered songs(by others), if they are
     * preffered, album
     * @param artist the artist we want to its
     *               songs
     */
    public static void deleteAllUserTrace(final Artist artist) {
        for (Album album : artist.getAlbums()) {
            for (Song songAlbum : album.getSongs()) {
                Library.getDatabase().getSongs().removeIf(song ->
                        song.getName().equals(songAlbum.getName()));
                for (User user : Library.getDatabase().getUsers()) {
                    user.getPrefferedSongs().removeIf(song2 ->
                            song2.equals(songAlbum));
                }
            }

            Library.getDatabase().getAlbums().removeIf(album1 ->
                    album1.getName().equals(album.getName()));
        }
    }

    /**
     * searches song by name
     *
     * @param name the name of song
     * @return returns the index of the song
     */
    public static int searchSongByName(final String name) {
        int i = 0;
        for (Song song : Library.getDatabase().getSongs()) {
            if (song.getName().equals(name)) {
                return i;
            }
            i++;
        }
        return -1;
    }

    /**
     * searches song by name and album
     *
     * @param songName  the name of song
     * @param albumName the name of album
     * @return returns the index of the song
     */
    public static int searchSongByNameAndAlbum(final String songName, final String albumName) {
        int i = 0;
        for (Song song : Library.getDatabase().getSongs()) {
            if (song.getName().equals(songName) && song.getAlbum().equals(albumName)) {

                return i;
            }
            i++;
        }
        return -1;
    }

    /**
     * our library function
     */
    public Library() {
    }

    /**
     * set Song function
     *
     * @param songs the list of songs
     */
    public void setSongs(final ArrayList<Song> songs) {
        this.songs = songs;
    }

    /**
     * set Podcast function
     *
     * @param podcasts the list of podcast
     */
    public void setPodcasts(final ArrayList<Podcast> podcasts) {
        this.podcasts = podcasts;
    }

    /**
     * SET USERS
     *
     * @param users the list of users
     */
    public void setUsers(final ArrayList<User> users) {
        this.users = users;
    }
    /**
     * Add user function which handles the case that the

     * @return json
     */
    public static JsonNode addUserJson() {
        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());

        switch (jsonElement.getType()) {
            case "artist" -> {
                if (Library.getDatabase().checkIfArtistValid(jsonElement.getUsername())) {
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " is already taken.");
                    return jsonObject;
                } else if (Library.getDatabase().checkIfHostValid(jsonElement.getUsername())
                        || Library.getDatabase().checkIfNormalUserValid(jsonElement.
                        getUsername())) {
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " is already taken.");
                    return jsonObject;
                } else {

                    for (int i = 0; i < Library.getDatabase().getArtistInstance(jsonElement.
                            getUsername()).getAlbums().size(); i++) {
                        Library.getDatabase().getArtistInstance(jsonElement.getUsername()).
                                getAlbums().get(i).getSongs().clear();
                    }
                    Library.getDatabase().getArtistInstance(jsonElement.getUsername()).
                            getAlbums().clear();
                    Library.getDatabase().addArtist(Library.
                            getDatabase().getArtistInstance(jsonElement.getUsername()));

                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " has been added successfully.");

                }
            }
            case "user" -> {
                if (Library.getDatabase().checkIfNormalUserValid(jsonElement.getUsername())) {
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " is already taken.");
                    return jsonObject;
                } else if (Library.getDatabase().checkIfHostValid(jsonElement.getUsername())
                        || Library.getDatabase().checkIfArtistValid(jsonElement.getUsername())) {
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " is already taken.");
                    return jsonObject;
                } else {
                    Library.getDatabase().addUser(Library.
                            getDatabase().getUserInstance(jsonElement.getUsername()));
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " has been added successfully.");

                }
            }
            case "host" -> {
                if (Library.getDatabase().checkIfHostValid(jsonElement.getUsername())) {
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " is already taken.");
                    return jsonObject;
                } else if (Library.getDatabase().checkIfNormalUserValid(jsonElement.
                        getUsername())
                        || Library.getDatabase().checkIfArtistValid(jsonElement.getUsername())) {
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " is already taken.");
                    return jsonObject;
                } else {

                    Library.getDatabase().addHost(Library.
                            getDatabase().getHostInstance(jsonElement.getUsername()));
                    jsonObject.put("message", "The username "
                            + jsonElement.getUsername() + " has been added successfully.");

                }
            }
            default -> {
                break;
            }
        }

        return jsonObject;


    }

    /**
     * we delete the user from the database
     * , and we check if the user is an artist, host or normal user
     * , and we check if the user is loaded in has a loaded song or podcast
     * ,and we check if it is in a playlist
     * then we delete all the traces of it, albums, songs, podcasts,
     * playlists, likesongs, followings etc.
     * if it isn't we delete the user
     */
    public static JsonNode deleteUserJson() {
        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());

        if (!Library.getDatabase().checkifUserInstance(jsonElement.getUsername())
                && !Library.getDatabase().checkIfHostValid(jsonElement.getUsername())) {

            if (!Library.getDatabase().checkIfArtistValid(jsonElement.getUsername())) {
                jsonObject.put("message",
                        jsonElement.getUsername() + " is not an artist.");
                return jsonObject;
            }
        }

        boolean status = false;
        for (User user : Library.getDatabase().getUsers()) {

            if (user.getUserDatabase().getAccesedUser() == null) {
                continue;
            }
            if (user.getUserDatabase().getAccesedUser().
                    equals(jsonElement.getUsername())) {
                status = true;
                break;

            }
        }

        if (status) {
            jsonObject.put("message",
                    jsonElement.getUsername() + " can't be deleted.");
            return jsonObject;
        }
        if (Library.getDatabase().checkifArtistInstance(jsonElement.getUsername())) {

            Artist artist4 = Library.getDatabase().
                    returnArtist(jsonElement.getUsername());
            if (artist4 != null) {

                for (Playlist playlist : Library.getDatabase().getPlaylistList()) {

                    for (Album album : Library.getDatabase().
                            returnArtist(jsonElement.getUsername()).getAlbums()) {

                        for (Song song : album.getSongs()) {

                            if (playlist.getSongList().contains(song.getName())) {

                                jsonObject.put("message",
                                        jsonElement.getUsername() + " can't be deleted.");
                                return jsonObject;
                            }
                        }

                    }
                }
            }

        }
        if (Library.getDatabase().checkifUserInstance(jsonElement.getUsername())) {
            User user = Library.getDatabase().
                    getUserInstance(jsonElement.getUsername());
            if (user != null) {
                for (User user3 : Library.getDatabase().getUsers()) {
                    if (user3.getUserDatabase().getLoadedPlaylist() != null) {
                        String loadPlaylist = user3.
                                getUserDatabase().getLoadedElement();
                        Playlist playlistLoad = user.
                                getUserDatabase().selectPlaylistByName(loadPlaylist);
                        if (playlistLoad != null) {
                            for (Playlist playlist
                                    : Library.getDatabase().getPlaylistList()) {
                                if (playlistLoad.getName().
                                        equals(playlist.getName()) && playlist.getOwner().
                                        equals(jsonElement.getUsername())) {
                                    jsonObject.put("message",
                                            jsonElement.getUsername() + " can't be deleted.");
                                    return jsonObject;
                                }
                            }
                        }


                    }
                }

            }

        }
        if (Library.getDatabase().checkIfHostValid(jsonElement.getUsername())) {
            Host host = Library.getDatabase().getHostInstance(jsonElement.getUsername());
            if (host != null) {
                for (User user3 : Library.getDatabase().getUsers()) {
                    if (user3.getUserDatabase().getLoadedPodcast() != null) {
                        String loadPodcast = user3.getUserDatabase().getLoadedElement();
                        Podcast podcastLoad = user3.
                                getUserDatabase().selectPodcastByName(loadPodcast);
                        if (podcastLoad != null) {
                            for (Podcast podcast : Library.getDatabase().getPodcasts()) {
                                if (podcastLoad.getName().
                                        equals(podcast.getName()) && podcast.getOwner().
                                        equals(jsonElement.getUsername())) {
                                    jsonObject.put("message",
                                            jsonElement.getUsername() + " can't be deleted.");
                                    return jsonObject;
                                }
                            }
                        }


                    }
                }

            }

        }

        if (Library.getDatabase().checkIfArtistValid(jsonElement.getUsername())) {

            Artist artist = Library.getDatabase().returnArtist(jsonElement.getUsername());
            Library.deleteAllUserTrace(artist);
            Library.getDatabase().getArtists().removeIf(artist2 ->
                    artist2.getUsername().equals(jsonElement.getUsername()));

        } else if (Library.getDatabase().checkIfHostValid(jsonElement.getUsername())) {

            Library.getDatabase().getHosts().removeIf(host ->
                    host.getUsername().equals(jsonElement.getUsername()));
        } else if (Library.getDatabase().checkIfNormalUserValid(jsonElement.
                getUsername())) {
            for (Playlist playlist : Library.getDatabase().getPlaylistList()) {
                if (playlist.getUsersFollow().contains(jsonElement.getUsername())) {
                    playlist.setFollowers(playlist.getFollowers() - 1);
                    playlist.getUsersFollow().removeIf(user2
                            -> user2.equals(jsonElement.getUsername()));
                }
            }
            Iterator<Playlist> iterator = Library.getDatabase().
                    getPlaylistList().iterator();
            while (iterator.hasNext()) {
                Playlist playlist2 = iterator.next();
                if (playlist2.getOwner().equals(jsonElement.getUsername())) {

                    iterator.remove();
                }
            }

            Library.getDatabase().getUsers().removeIf(user ->
                    user.getUsername().equals(jsonElement.getUsername()));
        }
        jsonObject.put("message", jsonElement.getUsername()
                + " was successfully deleted.");


        return jsonObject;


    }
    /**
     * returns the online status of a normal user
     * user can be online or offline
     * @return json
     */
    public static JsonNode onlineJson() {

        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());

        if (Library.getDatabase().checkIfNormalUserValid(jsonElement.getUsername())) {
            User user = Library.getDatabase().getUserInstance(jsonElement.getUsername());
            user.setOnlineStatus();
            jsonObject.put("message",
                    jsonElement.getUsername() + " has changed status successfully.");
        } else {
            if (Library.getDatabase().checkIfArtistValid(jsonElement.getUsername())
                    || Library.getDatabase().checkIfHostValid(jsonElement.getUsername())) {
                jsonObject.put("message", jsonElement.getUsername() + " is not a normal user.");
            } else {
                jsonObject.put("message",
                        "The username " + jsonElement.getUsername() + " doesn't exist.");
            }
        }


        return jsonObject;
    }

    /**
     * shows all users, artists, hosts
     * @return json
     */
    public static JsonNode showAllUsers() {
        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        boolean first = true;
        ArrayNode outputs = objectMapper.createArrayNode();

        for (User user : Library.getDatabase().getUsers()) {
            outputs.add(user.getUsername());
        }
        for (Artist artist : Library.getDatabase().getArtists()) {
            outputs.add(artist.getUsername());
        }
        for (Host host : Library.getDatabase().getHosts()) {
            outputs.add(host.getUsername());
        }
        jsonObject.put("result", outputs);

        return jsonObject;
    }

    /**
     * show all online normal users
     * @return json
     */
    public static JsonNode showAllOnlineUsers() {
        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        boolean first = true;
        ArrayNode outputs = objectMapper.createArrayNode();

        for (User user : Library.getDatabase().getUsers()) {
            if (user.getOnlineStatus().equals("online")) {
                outputs.add(user.getUsername());
            }
        }
        jsonObject.put("result", outputs);

        return jsonObject;
    }


}
