package types;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import database.Database;
import json.Filters.*;
import json.JsonConvertToCategories;
import lombok.Getter;
import lombok.Setter;
import status.playerLoad;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * In functia de user, am incercat sa implementez functie care sa ne foloseasca pentru fiecare
 * user, incercam sa implementez "un singleton" pentru fiecare user si sa interfereze
 * cu ceilalti useri
 * la database, de aceea am implementat un userDatabase.(vedeti functia Public User(String owner)).
 * Am implementat un PrefferdedSongs pentru user pentru a putea acesa melodiile preferate de user.
 * Si addPrefferedSongs si RemovedPrefered songs pentru a le adauga, respectiv elimina.
 */

@Getter

public class User {
    private static final String ONLINE = "online";
    @Getter
    @Setter
    private Boolean statusshuffle = false;
    @Getter
    @Setter
    private String searchType = "";
    @Getter
    @Setter
    private int repeat;
    @Getter
    @Setter
    private int loadedEpisode;

    @Getter
    private String accesedUser = "";
    /**
     * -- GETTER --
     * gets the index of the song
     *
     * @return the current index of our loaded song
     * within our album/playlis
     */
    @Getter
    private int songIndex;
    @Getter
    @Setter
    private int songindexrandom;
    @Setter
    @Getter
    private String pageStatus = "HOME";
    @Getter
    @Setter
    private String username;
    @Getter
    @Setter
    private int age;
    @Getter
    @Setter
    private String city;
    /**
     * -- GETTER --
     * get the online status of a user
     */
    @Getter
    private String onlineStatus = ONLINE;
    private final Database userDatabase;
    @Getter
    @Setter
    private String accesedUser2;
    @Getter
    private final List<Song> prefferedSongs = new ArrayList<>();
    @Setter
    private int prevtime;

    public User() {
        this.userDatabase = new Database();
    }

    public User(final String username) {
        this.username = username;
        this.onlineStatus = ONLINE;
        this.userDatabase = new Database();
    }

    /**
     * sets the index for the song list
     *
     * @param songIndex2 song index
     */
    public void setSongIndex(final int songIndex2) {
        this.songIndex = songIndex2;
    }

    /**
     * added prefered songs by user
     *
     * @param name of the song
     */
    public void addPrefferedSong(final Song name) {
        if (prefferedSongs.contains(name)) {
            return;
        }
        prefferedSongs.add(name);
    }

    /**
     * switches the online status of the user,
     * if it online, it will be offline and vice versa
     */
    public void switchConnectionStatus() {
        if (onlineStatus.equals(ONLINE)) {
            this.onlineStatus = "offline";
        } else {
            this.onlineStatus = ONLINE;
        }
    }

    /**
     * sets the online status of the user
     * if it online, it sets offline and vice-versa
     * it changes the online status
     */
    public void setOnlineStatus() {

        if (this.getOnlineStatus().equals("online")) {
            this.onlineStatus = "offline";
        } else {
            this.onlineStatus = "online";
        }
    }


    /**
     * removed liked song by user
     *
     * @param name name of the song
     */
    public void removePrefferedSong(final String name) {
        prefferedSongs.remove(name);
    }


    /**
     * here we are trying to implement a followJson function,
     * which changes the state of the playlist if we follow, unfollow and error
     */

    public JsonNode followJson() {


        ObjectNode jsonObject = new ObjectMapper().createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        User user = Library.getDatabase().getUserInstance(jsonElement.
                getUsername());
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        if (user.getUserDatabase().getSelectElement() == null
                || !user.getUserDatabase().getSelectStatus()) {
            jsonObject.put("message",
                    "Please select a source before following "
                            + "or unfollowing.");
            return jsonObject;
        }

        if (user.getUserDatabase().selectPlaylistByName(user.
                getUserDatabase().getSelectElement()) == null) {
            jsonObject.put("message", "The selected source"
                    + " is not a playlist.");
            return jsonObject;
        }

        Playlist playlist = user.getUserDatabase().
                selectPlaylistByName(user.getUserDatabase().
                        getSelectElement());
        assert playlist != null;
        if (playlist.getOwner().equals(Library.getDatabase().
                getJson().getUsername())) {
            jsonObject.put("message", "You cannot"
                    + " follow or unfollow your own playlist.");
            return jsonObject;
        } else {

            if (!playlist.searchUsersWhoFollowed(Library.
                    getDatabase().getJson().getUsername())) {

                jsonObject.put("message", "Playlist "
                        + "followed successfully.");
                playlist.getUsersFollow().add(jsonElement.getUsername());

                playlist.setFollowers(playlist.getFollowers() + 1);

            } else {

                jsonObject.put("message", "Playlist unfollowed"
                        + " successfully.");
                playlist.getUsersFollow().removeIf(user2
                        -> user2.equals(jsonElement.getUsername()));
                playlist.setFollowers(playlist.getFollowers() - 1);
            }

        }
        return jsonObject;
    }
    /**
     * this class if we try to implement,
     * if the size of the playlist is smaller than
     * playlistid-1 (we take them from 0), then we give an error
     * if it is not found in our function after
     * name, can be empty or invalid and error again,
     * if the item number in the selected item is
     * bigger than
     * selected.size() gives an error again, after that
     * we set the state
     * @return we set the state of the element,
     * whether it is public or private (depending on
     * by the preceding state, or if it was not
     * previously initialized the state (I give it
     * private)
     */
    public JsonNode visibilityJson() {

        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        User user = Library.getDatabase().getUserInstance(jsonElement.getUsername());

        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        List<String> selected = user.getUserDatabase().getSelected();
        List<Playlist> playlistUser = user.getUserDatabase().
                selectPlaylistByOwner(jsonElement.getUsername());
        if (playlistUser.size() <= (jsonElement.getPlaylistId() - 1)) {
            user.getUserDatabase().setSelectstatus(false);
            jsonObject.put("message",
                    "The specified playlist ID is too high.");
            return jsonObject;
        }
        Playlist playlistFilter = playlistUser.get(jsonElement.
                getPlaylistId() - 1);

        if (user.getUserDatabase().selectPlaylistByName(playlistFilter.
                getName()) == null) {
            user.getUserDatabase().setSelectstatus(false);
            jsonObject.put("message",
                    "The specified playlist ID is too high.");
            return jsonObject;
        }
        if (jsonElement.getItemNumber() > selected.size()) {
            user.getUserDatabase().setSelectstatus(false);
            jsonObject.put("message", "The selected ID is too high.");
            return jsonObject;
        } else {
            Playlist playlistselected = user.getUserDatabase().
                    selectPlaylistByName(playlistFilter.getName());
            if (playlistselected.getVisibility() == null) {
                jsonObject.put("message",
                        "Visibility status updated successfully "
                                + "to private.");
                playlistselected.setVisibility("private");
            } else {
                if (playlistselected.getVisibility().equals("private")) {
                    jsonObject.put("message",
                            "Visibility status updated successfully "
                                    + "to public.");
                    playlistselected.setVisibility("public");

                } else {
                    jsonObject.put("message", "Visibility status"
                            + " updated successfully to private.");
                    playlistselected.setVisibility("private");
                }
            }
        }
        return jsonObject;
    }

    /**
     * shows the songs liked by the user
     *
     * @return returns the songs liked by the user
     */
    public static JsonNode showsongliked() {
        ObjectMapper objectMapper = new ObjectMapper();

        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        User user = Library.getDatabase().getUserInstance(jsonElement.getUsername());
        ObjectNode jsonObject = objectMapper.createObjectNode();
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        List<Song> selected = new ArrayList<>(user.getPrefferedSongs());
        ArrayNode outputs = objectMapper.createArrayNode();
        if (user.getOnlineStatus().equals("online")) {

            for (Song elements : selected) {
                outputs.add(elements.getName());
            }

            jsonObject.set("result", outputs);
            user.getUserDatabase().setLoadStatus(false);
            user.getUserDatabase().setSelectstatus(false);
        } else {
            jsonObject.put("message", "User " + user.getUsername() + " is not logged in.");
        }
        return jsonObject;
    }
    /**
     * for the search function we try to
     * we implement a search, and share
     * in cases we use here
     * and the criteria classes on which
     * we built them, and we are making a function
     * selected upon which we add the elements
     * depending on what we have and will give them
     * we use later to select
     * Search is set to true, at status
     * operations we set it to false.
     * The element that was loaded is
     * empty, because I did a search
     * we are trying to search the json according to the filter
     * have selectedSongs for songs
     * which is a List<Song>
     * and selected which is a List<String>
     * for others
     *
     * @return json
     * @throws IOException exception for objectMAPPER
     */
    public JsonNode searchJsonByFilters() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();

        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();
        User user = Library.getDatabase().getUserInstance(jsonElement.getUsername());
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        String filterString = objectMapper.writeValueAsString(jsonElement.getFilters());
        List<String> selected = new ArrayList<>();
        List<Song> selectedSong;

        ArrayNode outputs = objectMapper.createArrayNode();
        user.getUserDatabase().setType(jsonElement.getType());
        if (user.getOnlineStatus().equals("online")) {
            switch (jsonElement.getType()) {
                case "song" -> {
                    SongFilters criteriaSong = objectMapper.
                            readValue(filterString, SongFilters.class);
                    selectedSong = criteriaSong.selectSongs(criteriaSong);
                    if (!user.getUserDatabase().getSelectedSong().isEmpty()) {
                        user.getUserDatabase().
                                addPreviousSelectedSong(user.getUserDatabase().getSelectedSong());
                    }
                    user.getUserDatabase().getSelectedSong().clear();
                    user.getUserDatabase().addSelectedSong(selectedSong);
                    user.getUserDatabase().setSearchType("song");
                    jsonObject.put("message",
                            "Search returned " + selectedSong.size() + " results");

                    for (Song elements : selectedSong) {
                        outputs.add(elements.getName());
                    }
                    jsonObject.set("results", outputs);

                    if (user.getUserDatabase().getLoadStatus() == null) {
                        user.getUserDatabase().setLoadStatus(false);
                    }
                    if (user.getUserDatabase().getStatus() != null) {
                        playerLoad playerLoad = user.getUserDatabase().getStatus();
                        if (playerLoad.getType() != null) {
                            if (playerLoad.getType().equals("song")) {
                                playerLoad.setName("");
                                playerLoad.setAlbum("");
                                playerLoad.setPaused(true);
                            }
                        }
                    }
                }
                case "podcast" -> {
                    Filters criteria = objectMapper.
                            readValue(filterString, Filters.class);
                    selected = criteria.select(criteria);
                    user.getUserDatabase().setSearchType("podcast");


                }
                case "playlist" -> {
                    PlaylistFilters
                            criteria = objectMapper.
                            readValue(filterString, PlaylistFilters.class);
                    selected = criteria.selectPlaylist(criteria, Library.getDatabase().
                            getJson().getUsername());
                    user.getUserDatabase().setSearchType("playlist");

                }
                case "artist" -> {
                    ArtistFilter criteria = objectMapper.
                            readValue(filterString, ArtistFilter.class);
                    selected = criteria.selectArtist(criteria);
                    user.getUserDatabase().setSearchType("artist");

                }
                case "host" -> {
                    ArtistFilter criteria = objectMapper.
                            readValue(filterString, ArtistFilter.class);
                    selected = criteria.selectHost(criteria);
                    user.getUserDatabase().setSearchType("host");

                }
                case "album" -> {
                    AlbumFilter criteria = objectMapper.
                            readValue(filterString, AlbumFilter.class);
                    selected = criteria.select(criteria);
                    user.getUserDatabase().setSearchType("album");

                }
                default -> {
                    break;
                }
            }
            if (!jsonElement.getType().equals("song")) {
                if (!user.getUserDatabase().getSelected().isEmpty()) {
                    user.getUserDatabase().
                            addPreviousSelected(user.getUserDatabase().getSelected());
                }
                user.getUserDatabase().addSelected(selected);
                jsonObject.put("message",
                        "Search returned " + selected.size() + " results");

                for (String elements : selected) {
                    outputs.add(elements);
                }
                jsonObject.set("results", outputs);
                if (user.getUserDatabase().getLoadStatus() == null) {
                    user.getUserDatabase().setLoadStatus(false);
                }
            }

            user.getUserDatabase().setAccesedUser("", user);
            user.getUserDatabase().setSearchstatus(true);
            user.getUserDatabase().setShufflestatus(false);
            user.getUserDatabase().setLoadedElement("");
            user.getUserDatabase().setSelectstatus(false);
            user.getUserDatabase().setLikestatus(false);


        } else {
            jsonObject.put("message",
                    jsonElement.getUsername() + " is offline.");
            jsonObject.put("results", outputs);
        }

        return jsonObject;
    }

    /**
     * we implement for select and select the element
     * as an index function, and we try to search for it in
     * the elements found in the searchclass
     * search status is set to false as it was
     * made the selection for search, and when selecting true
     * we have a different select for songs
     * because for songs we need the album
     * in order to search the song later

        /**
         * we try to search the json by filters
         * have selected which is a List<String>
         *     and selectedSong which is a List<Song>
         *        for songs as we need the album
         * @return json
         */
    public JsonNode selectJsonByFilters() {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode jsonObject = objectMapper.createObjectNode();
        JsonConvertToCategories jsonElement = Library.getDatabase().getJson();

        User user = Library.getDatabase().getUserInstance(jsonElement.getUsername());
        jsonObject.put("command", jsonElement.getCommand());
        jsonObject.put("user", jsonElement.getUsername());
        jsonObject.put("timestamp", jsonElement.getTimestamp());
        List<Song> selectedSong = new ArrayList<>();
        List<String> selected = new ArrayList<>();
        if (user.getUserDatabase().getSearchType().equals("song")) {
            selectedSong = new ArrayList<>(user.getUserDatabase().getSelectedSong());

        } else {
            selected = new ArrayList<>(user.getUserDatabase().getSelected());

        }
        if (user.getUserDatabase().getSearchstatus() == null) {
            jsonObject.put("message",
                    "Please conduct a search before making a selection.");
            return jsonObject;
        }
        if (!user.getUserDatabase().getSearchstatus()) {
            jsonObject.put("message",
                    "Please conduct a search before making a selection.");
            return jsonObject;
        }
        if (jsonElement.getItemNumber() > selected.size()
                && !user.getUserDatabase().getSearchType().equals("song")) {
            user.getUserDatabase().setSelectstatus(false);
            if (selected.isEmpty()) {
                user.getUserDatabase().
                        addSelected(user.getUserDatabase().getPreviousSelected());
                user.getUserDatabase().addPreviousSelected(new ArrayList<>());
            }
            jsonObject.put("message", "The selected ID is too high.");
            return jsonObject;

        } else if (jsonElement.getItemNumber() > selectedSong.size()
                && user.getUserDatabase().getSearchType().equals("song")) {
            user.getUserDatabase().setSelectstatus(false);
            if (selectedSong.isEmpty()) {
                user.getUserDatabase().addSelectedSong(user.
                        getUserDatabase().getPreviousSelectedSong());
                user.getUserDatabase().addPreviousSelectedSong(new ArrayList<>());
            }
            jsonObject.put("message", "The selected ID is too high.");
            return jsonObject;
        } else {

            user.getUserDatabase().setSelectstatus(true);
            if (user.getUserDatabase().getSearchType().equals("song")) {
                jsonObject.put("message", "Successfully selected "
                        + selectedSong.get(jsonElement.getItemNumber() - 1).getName() + ".");
                user.getUserDatabase().setElement(selectedSong.
                        get(jsonElement.getItemNumber() - 1).getName());
                user.getUserDatabase().setSelectElementAlbum(selectedSong.
                        get(jsonElement.getItemNumber() - 1).getAlbum());

                user.getUserDatabase().setAccesedUser(selectedSong.get(jsonElement.
                        getItemNumber() - 1).getArtist(), user);
                user.getUserDatabase().setSearchstatus(false);

                user.getUserDatabase().setLoadStatus(false);
                user.getUserDatabase().setSelectstatus(true);
                user.getUserDatabase().setLikestatus(false);
            } else {
                if (user.getUserDatabase().getSearchType().equals("artist")) {
                    Library.getDatabase().setArtistElement(selected.
                            get(jsonElement.getItemNumber() - 1));

                } else if (user.getUserDatabase().getSearchType().equals("host")) {
                    Library.getDatabase().setHostElement(selected.
                            get(jsonElement.getItemNumber() - 1));
                }
                jsonObject.put("message",
                        "Successfully selected " + selected.
                                get(jsonElement.getItemNumber() - 1) + ".");
                String stringuser = selected.get(jsonElement.getItemNumber() - 1);
                user.getUserDatabase().setElement(selected.
                        get(jsonElement.getItemNumber() - 1));

                Podcast podcast = Library.podcastByName(stringuser);
                if (podcast != null) {
                    if (Library.getDatabase().checkIfHostValid(podcast.getOwner())) {
                        user.getUserDatabase().setAccesedUser(podcast.getOwner(), user);
                    }
                }
                user.getUserDatabase().setSearchstatus(false);

                user.getUserDatabase().setLoadStatus(false);
                user.getUserDatabase().setSelectstatus(true);
                user.getUserDatabase().setLikestatus(false);

                if (Library.getDatabase().checkIfAlbumExists(user.
                        getUserDatabase().getElement())) {
                    Album album = Library.searchAlbumByName(user.
                            getUserDatabase().getElement());
                    user.getUserDatabase().setAccesedUser(album.getArtist(), user);
                    user.getUserDatabase().setSelectstatus(true);

                    jsonObject.put("message", "Successfully selected "
                            + user.getUserDatabase().getElement() + ".");
                    return jsonObject;
                } else if (Library.getDatabase().checkIfArtistValid(user.
                        getUserDatabase().getElement())) {
                    user.getUserDatabase().setAccesedUser(user.getUserDatabase().
                            getElement(), user);
                    user.getUserDatabase().setPageStatus("ARTIST");
                    jsonObject.put("message", "Successfully selected "
                            + user.getUserDatabase().getElement() + "'s page.");
                    return jsonObject;
                } else if (Library.getDatabase().checkIfHostValid(user.
                        getUserDatabase().getElement())) {
                    user.getUserDatabase().setAccesedUser(user.getUserDatabase().
                            getElement(), user);

                    user.getUserDatabase().setPageStatus("HOST");

                    jsonObject.put("message", "Successfully selected "
                            + user.getUserDatabase().getElement() + "'s page.");
                    return jsonObject;
                }
            }
        }

        user.getUserDatabase().setSearchstatus(false);

        user.getUserDatabase().setLoadStatus(false);
        user.getUserDatabase().setSelectstatus(true);
        user.getUserDatabase().setLikestatus(false);


        return jsonObject;
    }


}

