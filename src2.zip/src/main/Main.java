package main;

import checker.Checker;
import checker.CheckerConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.node.ArrayNode;
import json.JsonConvertToCategories;

import java.io.File;

import types.Library;
import types.User;
import json.JsonList;

import java.util.List;

import command.CommandRunner;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

/**
 * The entry point to this homework. It runs the checker that tests your implentation.
 */
public final class Main {

    static final String LIBRARY_PATH = CheckerConstants.TESTS_PATH + "library/library.json";

    public static String getLibraryPath() {
        return LIBRARY_PATH;
    }

    /**
     * for coding style
     */

    private Main() {
    }

    /**
     * DO NOT MODIFY MAIN METHOD
     * Call the checker
     *
     * @param args from command line
     * @throws IOException in case of exceptions to reading / writing
     */
    public static void main(final String[] args) throws IOException {
        File directory = new File(CheckerConstants.TESTS_PATH);
        Path path = Paths.get(CheckerConstants.RESULT_PATH);

        if (Files.exists(path)) {
            File resultFile = new File(String.valueOf(path));
            for (File file : Objects.requireNonNull(resultFile.listFiles())) {
                file.delete();
            }
            resultFile.delete();
        }
        Files.createDirectories(path);
        for (File file : Objects.requireNonNull(directory.listFiles())) {
            if (file.getName().startsWith("library")) {
                continue;
            }

            String filepath = CheckerConstants.OUT_PATH + file.getName();
            File out = new File(filepath);
            boolean isCreated = out.createNewFile();
            if (isCreated) {
                action(file.getName(), filepath);
            }


        }

        Checker.calculateScore();
    }

    /**
     * @param filePathInput  for input file
     * @param filePathOutput for output file
     * @throws IOException in case of exceptions to reading / writing
     *                     mai intai luam elementele
     *                     din functia noastra si le luam din LIBRARY_PATH,
     *                     ce este inputul cu informatii despre toate,
     *                     le punem in pentru ce avem nevoie si le punem in
     *                     database nostru comun de library, punem melodii,
     *                     podcasturi, userii si dupa
     *                     convertim userii in hash map
     *                     dupa luam pentru din checker constants jsonurile
     *                     de teste, si folosind clasa JsonConvertToCategories le convertim
     *                     in clasa noastre in ce avem nevoie, si dupa luam
     *                     in functie de userul nostru dat de catre json un database pentru
     *                     fiecare user si ce comanda vrem sa implementam,
     *                     avem changed_timestamp care marcheaza daca trebuie sa sincronizam
     *                     melodia din load cu timestampul cu functia
     *                     move_time_stamp, in cazul lui search(in care trebuie
     *                     sa facem asta inainte[ la shuffled, prev,next,like,repeat] pentru
     *                     a sincroniza cui ii facem actiunea respectiv,
     *                     la status,load, paused playPaused in care facem
     *                     sincronizarea in interiorul functiei, la restul
     *                     comenzilor le setam cu changed_timestamp
     *                     cu fals ca sa le sincronizam si trimitem jsonul
     *                     final, dupa ce stergem datele, si resetam
     *                     statusurile noastre si elementele care le-am pus
     *                     in loaded sau selectat
     */
    public static void action(final String filePathInput,
                              final String filePathOutput)
            throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Library librarycopy = objectMapper.readValue(new File(LIBRARY_PATH),
                Library.class);
        Library.getDatabase().setSongs(librarycopy.getSongs());
        Library.getDatabase().setPodcasts(librarycopy.getPodcasts());
        Library.getDatabase().setUsers(librarycopy.getUsers());
        Library.getDatabase().convertListToMap();
        ArrayNode outputs = objectMapper.createArrayNode();

        JsonList.readJsonFile(CheckerConstants.TESTS_PATH + filePathInput);
        List<JsonConvertToCategories> list = Library.getDatabase().getJsonList();
        for (JsonConvertToCategories element : list) {
            User user = Library.getDatabase().getUserInstance(element.getUsername());
            assert user != null;
            Library.getDatabase().setJson(element);
            boolean changedTimestamp = false;

            switch (element.getCommand()) {

                case "search" -> outputs.add(CommandRunner.searchCommand(user));
                case "select" -> outputs.add(CommandRunner.selectCommand(user));
                case "load" -> outputs.add(CommandRunner.loadCommand(user));
                case "status" -> outputs.add(CommandRunner.statusCommand(user));
                case "playPause" -> outputs.add(CommandRunner.playPauseCommand(user));
                case "createPlaylist" -> outputs.add(CommandRunner.createPlaylistCommand(user));
                case "addRemoveInPlaylist" -> outputs.add(CommandRunner.
                        addRemoveInPlaylistCommand(user));
                case "like" -> outputs.add(CommandRunner.likeCommand(user));
                case "showPlaylists" -> outputs.add(CommandRunner.showPlaylistsCommand(user));
                case "showPreferredSongs" -> outputs.add(CommandRunner.
                        showPreferredSongsCommand(user));
                case "repeat" -> outputs.add(CommandRunner.repeatCommand(user));
                case "shuffle" -> outputs.add(CommandRunner.shuffleCommand(user));
                case "forward" -> outputs.add(CommandRunner.forwardCommand(user));
                case "backward" -> outputs.add(CommandRunner.backwardCommand(user));
                case "prev" -> outputs.add(CommandRunner.prevCommand(user));
                case "next" -> outputs.add(CommandRunner.nextCommand(user));
                case "follow" -> outputs.add(CommandRunner.followCommand(user));
                case "switchVisibility" -> outputs.add(CommandRunner.switchVisibilityCommand(user));
                case "getTop5Playlists" -> outputs.add(CommandRunner.getTop5PlaylistsCommand());
                case "getTop5Songs" -> outputs.add(CommandRunner.getTop5SongsCommand());
                case "switchConnectionStatus" -> outputs.add(CommandRunner.
                        switchConnectionStatusCommand(user));
                case "getOnlineUsers" -> outputs.add(CommandRunner.getOnlineUsersCommand(user));
                case "addUser" -> outputs.add(CommandRunner.addUserCommand(user));
                case "addAlbum" -> outputs.add(CommandRunner.addAlbumCommand(user));
                case "showAlbums" -> outputs.add(CommandRunner.showAlbumsCommand(user));
                case "printCurrentPage" -> outputs.add(CommandRunner.printCurrentPageCommand(user));
                case "addMerch" -> outputs.add(CommandRunner.addMerchCommand(user));
                case "addEvent" -> outputs.add(CommandRunner.addEventCommand(user));
                case "deleteUser" -> outputs.add(CommandRunner.deleteUserCommand());
                case "getAllUsers" -> outputs.add(CommandRunner.getAllUsersCommand(user));
                case "addPodcast" -> outputs.add(CommandRunner.addPodcastCommand(user));
                case "addAnnouncement" -> outputs.add(CommandRunner.addAnnouncementCommand(user));
                case "removeAnnouncement" -> outputs.add(CommandRunner.
                        removeAnnouncementCommand(user));
                case "showPodcasts" -> outputs.add(CommandRunner.showPodcastsCommand(user));
                case "removeAlbum" -> outputs.add(CommandRunner.removeAlbumCommand(user));
                case "changePage" -> outputs.add(CommandRunner.changePageCommand(user));
                case "removePodcast" -> outputs.add(CommandRunner.removePodcastCommand(user));
                case "removeEvent" -> outputs.add(CommandRunner.removeEventCommand(user));
                case "getTop5Albums" -> outputs.add(CommandRunner.getTop5AlbumsCommand(user));
                case "getTop5Artists" -> outputs.add(CommandRunner.getTop5ArtistsCommand(user));
                default -> {
                    break;
                }


            }
            user.setPrevtime(element.getTimestamp());

        }
        CommandRunner.removePreviousData();
        // TODO add your implementation

        ObjectWriter objectWriter = objectMapper.writerWithDefaultPrettyPrinter();
        objectWriter.writeValue(new File(filePathOutput), outputs);
    }
}
